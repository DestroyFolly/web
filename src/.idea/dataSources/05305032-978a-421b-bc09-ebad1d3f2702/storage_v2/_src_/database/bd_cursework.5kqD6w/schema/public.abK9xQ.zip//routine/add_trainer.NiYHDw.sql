create function add_trainer() returns trigger
    language plpgsql
as
$$
DECLARE
    max_trainer_id INT;
BEGIN
    SELECT COALESCE(MAX(id), 0) + 1 INTO max_trainer_id FROM trainer;
    IF NEW.role = 't' THEN
        INSERT INTO trainer (id, gender, first_name, surname, number, position_id, gym_id)
        VALUES (max_trainer_id, NEW.gender, NEW.first_name, NEW.surname, NEW.phone, 1, 1);
    END IF;
    RETURN NEW;
END;
$$;

alter function add_trainer() owner to postgres;

