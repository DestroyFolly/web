from __future__ import annotations

from enum import Enum


class PaymentStatus(Enum):
    passed = 1
    not_passed = 2


class Payment:
    def __init__(self,
                 id: int | None = None,
                 all_price: float | None = None,
                 state: PaymentStatus | None = None) -> None:
        self.id = id
        self.all_price = all_price
        self.state = state
