from __future__ import annotations

from enum import Enum


class UserRole(Enum):
    admin = 1
    customer = 2
    seller = 3


class User:
    def __init__(self,
                 id: int | None = None,
                 fio: str | None = None,
                 email: str | None = None,
                 password: str | None = None,
                 money: int | None = None,
                 phone: str | None = None,
                 role: str | None = None) -> None:
        self.id = id
        self.fio = fio
        self.email = email
        self.password = password
        self.money = money
        self.phone = phone
        self.role = role
