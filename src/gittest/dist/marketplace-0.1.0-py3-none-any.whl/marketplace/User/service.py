from __future__ import annotations

from typing import TYPE_CHECKING

from model import User


if TYPE_CHECKING:
    from repository import UserRepository


class UserService:
    def __init__(self, repo: UserRepository) -> None:
        self.repo = repo

    def new_user_service(self, repo: UserRepository) -> UserService:
        return UserService(repo)

    def login(self, email: str) -> User:
        return self.repo.get_user_by_email(email)

    def register(self, email: str, password: str) -> User | None:
        user = self.repo.get_user_by_email(email)

        if user is not None:
            return None

        new_user = User(email=email, password=password)

        return self.repo.create(new_user)

    def get_user_by_id(self, id: int) -> User:
        return self.repo.get_user_by_id(id)

    def get_user_by_email(self, email: str) -> User:
        return self.repo.get_user_by_email(email)
