from __future__ import annotations


class Cart:
    def __init__(self,
                 id: int | None = None,
                 all_price: int | None = None) -> None:
        self.id = id
        self.all_price = all_price
