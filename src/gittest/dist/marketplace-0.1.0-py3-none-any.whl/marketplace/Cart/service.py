from __future__ import annotations

from typing import TYPE_CHECKING

from marketplace.Product.model import Product


if TYPE_CHECKING:
    from model import Cart
    from repository import CartRepository


class CartService:
    def __init__(self, repo: CartRepository) -> None:
        self.repo = repo

    def new_cart_service(self, repo: CartRepository) -> CartService:
        return CartService(repo)

    def add_product(self, user_id: int, product: Product | None) -> Cart | None:
        user = self.repo.get_cart_by_user_id(user_id)

        if user is None:
            return None

        return self.repo.create(product)

    def remove_product(self, user_id: int, product: Product | None) -> Cart | None:
        user = self.repo.get_cart_by_user_id(user_id)

        if user is None:
            return None

        return self.repo.update(product)

    def get_cart_by_user_id(self, id: int) -> Cart:
        return self.repo.get_cart_by_user_id(id)
