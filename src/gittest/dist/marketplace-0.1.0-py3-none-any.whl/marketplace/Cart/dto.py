from __future__ import annotations

from typing import TYPE_CHECKING


if TYPE_CHECKING:
    from marketplace.Product.model import Product


class AddProductCartReq:
    def __init__(self, user_id: int, product: Product) -> None:
        self.user_id = user_id
        self.product = product


class RemoveProductCartReq:
    def __init__(self, user_id: int, product: Product) -> None:
        self.user_id = user_id
        self.product_id = product
