from __future__ import annotations

from model import Order


class OrderRepository:
    def __init__(self) -> None:
        pass

    def create(self, new: Order) -> Order:
        pass

    def update(self, old: Order) -> None:
        pass

    def get_orders(self) -> list[Order]:
        return [Order()]

    def get_order_by_user_id(self, id: int) -> Order:
        pass
