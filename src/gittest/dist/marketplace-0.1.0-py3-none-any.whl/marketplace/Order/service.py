from __future__ import annotations

from typing import TYPE_CHECKING


if TYPE_CHECKING:
    from model import Order
    from repository import OrderRepository


class OrderService:
    def __init__(self, repo: OrderRepository) -> None:
        self.repo = repo

    def new_order_service(self, repo: OrderRepository) -> OrderService:
        return OrderService(repo)

    def add_order(self, user_id: int, order: Order | None) -> Order | None:
        user = self.repo.get_order_by_user_id(user_id)

        if user is None:
            return None

        return self.repo.create(order)

    def remove_order(self, user_id: int, order: Order | None) -> list[Order] | None:
        user = self.repo.get_order_by_user_id(user_id)

        if user is None:
            return None

        return self.repo.update(order)

    def get_orders(self) -> list[Order]:
        return self.repo.get_orders()

    def get_order_by_user_id(self, id: int) -> Order:
        return self.repo.get_order_by_user_id(id)
