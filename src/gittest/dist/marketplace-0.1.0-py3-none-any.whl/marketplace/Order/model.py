from __future__ import annotations


class Order:
    def __init__(self,
                 id: int | None = None,
                 all_price: int | None = None,
                 address: str | None = None,
                 date: str | None = None) -> None:
        self.id = id
        self.all_price = all_price
        self.address = address
        self.date = date
