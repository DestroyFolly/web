from __future__ import annotations

from model import Product


class ProductRepository:
    def __init__(self) -> None:
        pass

    def create(self, new: Product) -> Product:
        pass

    def update(self, old: Product) -> None:
        pass

    def get_products(self) -> list[Product]:
        return [Product()]

    def get_product_by_user_id(self, id: int) -> Product:
        pass
