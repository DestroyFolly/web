from __future__ import annotations

from typing import TYPE_CHECKING


if TYPE_CHECKING:
    from model import Product
    from repository import ProductRepository


class ProductService:
    def __init__(self, repo: ProductRepository) -> None:
        self.repo = repo

    def new_product_service(self, repo: ProductRepository) -> ProductService:
        return ProductService(repo)

    def add_product(self, user_id: int, product: Product | None) -> Product | None:
        user = self.repo.get_product_by_user_id(user_id)

        if user is None:
            return None

        return self.repo.create(product)

    def remove_product(self, user_id: int, product: Product | None) -> list[Product] | None:
        user = self.repo.get_product_by_user_id(user_id)

        if user is None:
            return None

        return self.repo.update(product)

    def get_products(self) -> list[Product]:
        return self.repo.get_products()

    def get_product_by_user_id(self, id: int) -> Product:
        return self.repo.get_product_by_user_id(id)
