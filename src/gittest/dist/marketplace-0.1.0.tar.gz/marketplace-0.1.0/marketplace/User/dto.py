from __future__ import annotations

from typing import TYPE_CHECKING


if TYPE_CHECKING:
    from model import User


class RegisterReq:
    def __init__(self, email: str, password: str) -> None:
        self.email = email
        self.password = password


class RegisterRes:
    def __init__(self, user: User) -> None:
        self.user = user


class LoginReq:
    def __init__(self, email: str, password: str) -> None:
        self.email = email
        self.password = password


class LoginRes:
    def __init__(self, user: User) -> None:
        self.user = user
