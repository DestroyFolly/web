from __future__ import annotations

from typing import TYPE_CHECKING


if TYPE_CHECKING:
    from model import User


class UserRepository:
    def __init__(self) -> None:
        pass

    def create(self, new: User) -> User:
        pass

    def update(self, old: User) -> None:
        pass

    def get_user_by_id(self, id: int) -> User:
        pass

    def get_user_by_email(self, email: str) -> User:
        pass
