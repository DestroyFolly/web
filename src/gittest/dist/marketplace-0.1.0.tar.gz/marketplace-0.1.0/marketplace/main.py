from __future__ import annotations


def main() -> None:
    print("Hello")
    input()


if __name__ == "__main__":
    main()
