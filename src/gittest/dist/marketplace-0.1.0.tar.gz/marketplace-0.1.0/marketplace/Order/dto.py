from __future__ import annotations

from typing import TYPE_CHECKING


if TYPE_CHECKING:
    from model import Order


class AddOrderReq:
    def __init__(self, user_id: int, order: Order) -> None:
        self.user_id = user_id
        self.order = order


class RemoveOrderReq:
    def __init__(self, user_id: int, order: Order) -> None:
        self.user_id = user_id
        self.order = order
