from __future__ import annotations

from typing import TYPE_CHECKING


if TYPE_CHECKING:
    from model import Product


class AddProductReq:
    def __init__(self, user_id: int, product: Product) -> None:
        self.user_id = user_id
        self.product = product


class RemoveProductReq:
    def __init__(self, user_id: int, product: Product) -> None:
        self.user_id = user_id
        self.product = product
