from __future__ import annotations


class Product:
    def __init__(self,
                 id: int | None = None,
                 price: float | None = None,
                 quantity: int | None = None,
                 rate: float | None = None) -> None:
        self.id = id
        self.price = price
        self.quantity = quantity
        self.rate = rate
