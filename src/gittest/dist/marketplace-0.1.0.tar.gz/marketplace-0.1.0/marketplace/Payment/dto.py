from __future__ import annotations

from typing import TYPE_CHECKING


if TYPE_CHECKING:
    from model import Payment


class AddPaymentReq:
    def __init__(self, user_id: int, payment: Payment) -> None:
        self.user_id = user_id
        self.payment = payment


class RemovePaymentReq:
    def __init__(self, user_id: int, payment: Payment) -> None:
        self.user_id = user_id
        self.payment = payment
