from __future__ import annotations

from model import Payment


class PaymentRepository:
    def __init__(self) -> None:
        pass

    def create(self, new: Payment) -> Payment:
        pass

    def update(self, old: Payment) -> None:
        pass

    def get_payments(self) -> list[Payment]:
        return [Payment()]

    def get_payment_by_user_id(self, id: int) -> Payment:
        pass
