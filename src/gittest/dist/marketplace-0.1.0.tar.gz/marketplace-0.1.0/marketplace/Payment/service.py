from __future__ import annotations

from typing import TYPE_CHECKING


if TYPE_CHECKING:
    from model import Payment
    from repository import PaymentRepository


class PaymentService:
    def __init__(self, repo: PaymentRepository) -> None:
        self.repo = repo

    def new_payment_service(self, repo: PaymentRepository) -> PaymentService:
        return PaymentService(repo)

    def add_payment(self, user_id: int, payment: Payment | None) -> Payment | None:
        user = self.repo.get_payment_by_user_id(user_id)

        if user is None:
            return None

        return self.repo.create(payment)

    def remove_payment(self, user_id: int, payment: Payment | None) -> list[Payment] | None:
        user = self.repo.get_payment_by_user_id(user_id)

        if user is None:
            return None

        return self.repo.update(payment)

    def get_payments(self) -> list[Payment]:
        return self.repo.get_payments()

    def get_payment_by_user_id(self, id: int) -> Payment:
        return self.repo.get_payment_by_user_id(id)
