from __future__ import annotations

from typing import TYPE_CHECKING


if TYPE_CHECKING:
    from model import Cart

    from marketplace.Product.model import Product


class CartRepository:
    def __init__(self) -> None:
        pass

    def create(self, new: Product) -> Cart:
        pass

    def update(self, old: Product) -> None:
        pass

    def get_cart_by_user_id(self, id: int) -> Cart:
        pass
